package javaapplication2;
import java.util.Scanner;
public class BagelsTest {
    public static void main(String[] args){
       Bagels myBagels = new Bagels() ;
      myBagels.playGame();
      
    


}
}
        
    


